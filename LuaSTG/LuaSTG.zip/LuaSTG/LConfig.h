#pragma once

#define LUASTG_NAME          "LuaSTG"
#define LUASTG_BRANCH        "Nexus"
#define LUASTG_VERSION_NAME  "v0.1.2"
#define LUASTG_VERSION_MAJOR 0
#define LUASTG_VERSION_MINOR 1
#define LUASTG_VERSION_PATCH 2

#define LUASTG_INFO LUASTG_NAME " " LUASTG_BRANCH " " LUASTG_VERSION_NAME

//#define LuaSTG_enable_GameObjectManager_Debug 1

//#define LDEVVERSION 1
